/* ============================================================
   rpw-base64-migrate.js — base64 képek KIKÖLTÖZTETÉSE a job JSON-ból Storage-ba (#10)
   NEM DESTRUKTÍV: detektál → feltölt → checksum-verify → path-referencia →
   base64 BACKUP-ba (csak megerősített feltöltés után) ; resume + rollback ; dry-run.
   Keretrendszer-mentes (böngésző admin oldal / node). Globál: RPWMigrate.
   ============================================================ */
(function(root){
  'use strict';
  // egyszerű, determinisztikus checksum (djb2) a base64 tartalomra
  function checksum(str){ var h=5381; for(var i=0;i<str.length;i++){ h=((h<<5)+h+str.charCodeAt(i))>>>0; } return h.toString(16)+':'+str.length; }
  function stripPrefix(dataUrl){ return String(dataUrl||'').replace(/^data:[^;]+;base64,/, ''); }

  // Megkeresi a base64 mezőket a jobban. Visszaad: [{key, get, set, clear, b64}]
  function scanJob(job){
    var out=[];
    if(!job) return out;
    function pushArr(arr, prefix){
      if(!Array.isArray(arr)) return;
      arr.forEach(function(it,i){
        if(it && typeof it.data==='string' && it.data.indexOf('data:')===0){
          out.push({ key: prefix+'_'+i, b64: it.data,
            set:function(path){ it.path=path; }, clear:function(bk){ it._b64=it.data; it.data=null; } });
        }
      });
    }
    pushArr(job.reconstPhotos,'reconst');
    pushArr(job.closingPhotos,'closing');
    if(job.elements && typeof job.elements==='object'){
      Object.keys(job.elements).forEach(function(k){
        var e=job.elements[k];
        if(e && typeof e.photo==='string' && e.photo.indexOf('data:')===0){
          out.push({ key:'elem_'+k, b64:e.photo,
            set:function(path){ e.photoPath=path; }, clear:function(){ e._photoB64=e.photo; e.photo=null; } });
        }
      });
    }
    return out;
  }

  // Dry-run terv: mit migrálnánk (nincs mutáció, nincs feltöltés)
  function plan(jobs){
    var items=0, bytes=0, perJob=[];
    (jobs||[]).forEach(function(j){
      var f=scanJob(j); var b=f.reduce(function(a,x){return a+stripPrefix(x.b64).length;},0);
      if(f.length){ items+=f.length; bytes+=b; perJob.push({id:j.id, count:f.length, bytes:b}); }
    });
    return { jobs:perJob.length, items:items, approxBytes:bytes, perJob:perJob };
  }

  // Egy job migrálása. sb: {storage:{from(bucket):{upload(path,blob,opts)}}}. opts:{bucket,dryRun,onLog,decode}
  async function migrateJob(job, sb, opts){
    opts=opts||{}; var bucket=opts.bucket||(root.RPW_CFG&&root.RPW_CFG.BUCKET)||'rpw-photos';
    var log=[]; var found=scanJob(job);
    if(!job.photoKeys) job.photoKeys={};
    for(var i=0;i<found.length;i++){
      var it=found[i], path=job.id+'/'+it.key+'.jpg', cs=checksum(stripPrefix(it.b64));
      // RESUME: ha már migrált (van photoKey), kihagyjuk
      if(job.photoKeys[it.key]===true){ log.push({key:it.key, status:'skip-done'}); continue; }
      if(opts.dryRun){ log.push({key:it.key, status:'dry-run', path:path, checksum:cs}); continue; }
      try{
        var blob = opts.decode ? opts.decode(it.b64) : it.b64;   // böngészőben dataURL→Blob; node-ban a stub kezeli
        var up = await sb.storage.from(bucket).upload(path, blob, {contentType:'image/jpeg', upsert:true});
        if(up && up.error) throw up.error;
        // VERIFY: a feltöltött path visszaigazolása (a stub/valós upload data.path-ot ad)
        var okPath = up && up.data && (up.data.path || up.data.Key || path);
        if(!okPath) throw new Error('upload verify failed');
        // Referencia beállítása + base64 BACKUP (nem törlés, csak null + _b64 mentés)
        it.set(path); it.clear();
        job.photoKeys[it.key]=true;
        if(!job.photoUrls) job.photoUrls={};
        job.photoUrls[it.key]=path; // aláírt URL-t a megjelenítéskor a signed-URL réteg ad
        log.push({key:it.key, status:'migrated', path:path, checksum:cs});
      }catch(e){ log.push({key:it.key, status:'error', error:String(e&&e.message||e)}); }
      if(opts.onLog) try{opts.onLog(log[log.length-1])}catch(_){}
    }
    return { id:job.id, migrated:log.filter(function(x){return x.status==='migrated';}).length,
             skipped:log.filter(function(x){return x.status==='skip-done';}).length,
             errors:log.filter(function(x){return x.status==='error';}).length, log:log };
  }

  // ROLLBACK: visszaállítja a base64-et a backupból (ha a migráció után baj lenne)
  function rollbackJob(job){
    var n=0;
    ['reconstPhotos','closingPhotos'].forEach(function(a){
      if(Array.isArray(job[a])) job[a].forEach(function(it){ if(it && it._b64){ it.data=it._b64; delete it._b64; delete it.path; n++; } });
    });
    if(job.elements) Object.keys(job.elements).forEach(function(k){ var e=job.elements[k]; if(e && e._photoB64){ e.photo=e._photoB64; delete e._photoB64; delete e.photoPath; if(job.photoKeys) delete job.photoKeys['elem_'+k]; n++; } });
    return n;
  }

  var api={ scanJob:scanJob, plan:plan, migrateJob:migrateJob, rollbackJob:rollbackJob, checksum:checksum };
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
  root.RPWMigrate=api;
})(typeof self!=='undefined'?self:(typeof window!=='undefined'?window:globalThis));
